﻿using UnityEngine;
using System.Collections;

public class Utils
{
    public static Vector3 GetDirectionVector(Transform transform)
    {
        float angle = transform.rotation.eulerAngles.z * Mathf.Deg2Rad;
        return new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0.0f);
    }
}
