﻿using UnityEngine;
using System.Collections;

public class ProjectileController : MonoBehaviour
{
    public float ProjectileSpeed = 1.0f;

    private void Update()
    {
        transform.position += Utils.GetDirectionVector(transform) * ProjectileSpeed * Time.deltaTime;

        if (IsOutOfBounds(transform.position.x) || IsOutOfBounds(transform.position.y))
            Destroy(gameObject);
    }

    private bool IsOutOfBounds(float position)
    {
        return (position < MIN || position > MAX);
    }

    private Vector3 mVelocity;

    private const float MIN = -10.0f;
    private const float MAX = 10.0f;
}
