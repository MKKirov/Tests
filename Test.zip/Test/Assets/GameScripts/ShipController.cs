﻿using UnityEngine;
using System.Collections;

public class ShipController : MonoBehaviour 
{
    public GameObject BulletPrefab;
    public GameObject FireBallPrefab;

    public ButtonEvents B_event;

    private void Awake()
    {
        float currentTime = Time.realtimeSinceStartup;
        mLastBulletTime = currentTime;
        mLastFireBallTime = currentTime;
        mLastHyperSpaceTime = currentTime;

        Manage_CDs();
        B_event.IsPaused += OnPause;
    }

    private void OnDestroy()
    {
        B_event.IsPaused -= OnPause;
    }

    private void Manage_CDs()
    {
        FakeStoreService srv = FakeStoreService.Instance();

        Has_CD_Shot = HasCooledDown;
        Has_CD_FireBall = Disable_action;
        Has_CD_HyperSpace = Disable_action;

        if (srv.Bought("com.powerups.fireball"))
            Has_CD_FireBall = HasCooledDown;

        if (srv.Bought("com.powerups.hyperspace"))
            Has_CD_HyperSpace = HasCooledDown;
    }

    private void Update()
    {
        ApplyMovement();
        ProcessContinuousInput();
        ProcessActionInput();
    }

    private void ApplyMovement()
    {
        transform.position += mVelocity * Time.deltaTime;
        mVelocity *= Mathf.Pow(DAMPING, Time.deltaTime);
    }
        
    private void ProcessContinuousInput()
    {
        if (Input.GetKey(KeyCode.UpArrow))
            mVelocity += Utils.GetDirectionVector(transform) * ACCELERATION * Time.deltaTime;

        if (Input.GetKey(KeyCode.LeftArrow))
            transform.Rotate(new Vector3(0.0f, 0.0f, ANGULAR_VELOCITY * Time.deltaTime));
        else if (Input.GetKey(KeyCode.RightArrow))
            transform.Rotate(new Vector3(0.0f, 0.0f, -ANGULAR_VELOCITY * Time.deltaTime));
    }

    private void ProcessActionInput()
    {
        if (Has_CD_Shot(mLastBulletTime) && Input.GetKeyDown(KeyCode.Z))
        {
            mLastBulletTime = Time.realtimeSinceStartup;
            SpawnProjectile(BulletPrefab);
        }
        else if (Has_CD_FireBall(mLastFireBallTime) && Input.GetKeyDown(KeyCode.X))
        {
            mLastFireBallTime = Time.realtimeSinceStartup;
            SpawnProjectile(FireBallPrefab);
        }
        else if (Has_CD_HyperSpace(mLastHyperSpaceTime) && Input.GetKeyDown(KeyCode.C))
        {
            mLastHyperSpaceTime = Time.realtimeSinceStartup;

            float x = Random.Range(-5.0f, 5.0f);
            float y = Random.Range(-5.0f, 5.0f);
            transform.position = new Vector3(x, y, 0.0f);

            mVelocity = Vector3.zero;
        }
    }

    private bool HasCooledDown(float time)
    {
        return (Time.realtimeSinceStartup - time >= 0.3f);
    }

    private bool Disable_action(float time)
    {
        return false;
    }

    private void SpawnProjectile(GameObject prefab)
    {
        GameObject projectile = Instantiate(prefab);
        projectile.transform.position = transform.position + Utils.GetDirectionVector(transform) * 0.9f;
        projectile.transform.localRotation = transform.localRotation;
    }

    private delegate bool Has_CD(float last_click);

    private Has_CD Has_CD_Shot;
    private Has_CD Has_CD_FireBall;
    private Has_CD Has_CD_HyperSpace;

    private void OnPause(bool isPaused)
    {
        if (isPaused)
        {
            Has_CD_Shot = Disable_action;
            Has_CD_FireBall = Disable_action;
            Has_CD_HyperSpace = Disable_action;
        }
        else
        {
            Manage_CDs();
        }
    }

    private Vector3 mVelocity;
    private float mLastBulletTime;
    private float mLastFireBallTime;
    private float mLastHyperSpaceTime;

    private const float ACCELERATION = 10.0f;
    private const float DAMPING = 0.4f;
    private const float ANGULAR_VELOCITY = 80.0f;
}
