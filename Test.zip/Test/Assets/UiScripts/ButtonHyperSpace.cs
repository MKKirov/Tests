﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonHyperSpace : MonoBehaviour
{
    public ButtonEvents B_event;
    private Text txt;
    private readonly string _tag = "com.powerups.hyperspace";

    private void Awake()
    {
        txt = GetComponentInChildren<Text>();

        B_event.Init(txt, _tag);
        B_event.Subscribe(_tag, txt);
    }

    public void OnClicked()
    {
        B_event.OnClick(_tag, txt);
    }
}
