﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonFireBall : MonoBehaviour
{
    public ButtonEvents B_event;
    private Text txt;
    private readonly string _tag = "com.powerups.fireball";

    private void Awake()
    {
        txt = GetComponentInChildren<Text>();

        B_event.Init(txt, _tag);
        B_event.Subscribe(_tag, txt);
    }

    public void OnClicked()
    {
        B_event.OnClick(_tag, txt);
    }

    private void OnDestroy()
    {
        B_event.Clear_events();
    }
}
