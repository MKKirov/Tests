﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonX : MonoBehaviour
{
    private Canvas canvas;
    public ButtonEvents B_event;

    public Text FireBall;
    public Text HyperSpace;
    public Color enable_col;

    private void Awake()
    {
        canvas = GetComponentInParent<Canvas>();
        UpdateTilePowUps();
    }

    public void OnClicked()
    {
        canvas.enabled = false;
        B_event.Pause_Game(false);
        UpdateTilePowUps();
    }

    private void UpdateTilePowUps()
    {
        FakeStoreService srv = FakeStoreService.Instance();

        if (FireBall != null)
        {
            if (srv.Bought("com.powerups.fireball"))
            {
                FireBall.color = enable_col;
            }
            if (srv.Bought("com.powerups.hyperspace"))
            {
                HyperSpace.color = enable_col;
            }
        }
    }
}
