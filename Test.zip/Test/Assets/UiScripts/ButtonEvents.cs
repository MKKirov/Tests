﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "ButtonEvent", menuName = "Events/Buttons")]
public class ButtonEvents : ScriptableObject
{
    public Color unlockedColor;
    public string lockedText;
    public Color lockedColor;
    public string waitingText;
    public Color waitingColor;

    public event Action<bool> IsPaused;
    Action<string, bool> actS, actS_all;
    Action<string> actF, actF_all;
    Action updButtons;
    Action updB;

    public void Clear_events()
    {
        updButtons = null;
        actF = null;
        actS = null;
    }

    public void Subscribe(string _tag, Text txt)
    {
        string bText = txt.text;

        FakeStoreService Service = FakeStoreService.Instance();       

        actF = item =>
        {
            if (_tag == item)
            {
                txt.text = bText;
                txt.color = lockedColor;
            }
        };
        Service.OnPurchaseFailed += actF;

        actS = (item, upd_othr) =>
        {
            if (_tag == item)
            {
                if (!upd_othr)
                    Upd_all(false, txt, _tag);
                else
                    Upd_all();
            }
        };
        Service.OnPurchaseSucceeded += actS;
    }

    public void OnClick(string _tag, Text txt)
    {
        if (FakeStoreService.Instance().Purchase(_tag))
        {
            txt.text = waitingText;
            txt.color = waitingColor;
        }
    }

    public void Init(Text txt, string pUps)
    {
        if (FakeStoreService.Instance().Bought(pUps))
        {
            txt.text = FakeStoreService.Instance().Pow_Up(pUps);
            txt.color = unlockedColor;
        }
        else
        {
            updB = () =>
              {
                  txt.text = FakeStoreService.Instance().Pow_Up(pUps);
                  txt.color = unlockedColor;

                  updButtons -= updB;
              };

            updButtons += updB;
        }
    }

    void Upd_all(bool othr = true, Text txt = null, string _tag="")
    {
        if (!othr)
        {
            txt.text = FakeStoreService.Instance().Pow_Up(_tag);
            txt.color = unlockedColor;
        }
        else
        {
            if (updButtons != null)
                updButtons();
        }
    }

    public void Pause_Game(bool pause)
    {
        if (pause)
        {
            Time.timeScale = 0f;
            Time.fixedDeltaTime = 0f;

            if (IsPaused != null)
                IsPaused(true);
        }
        else
        {
            if (IsPaused != null)
                IsPaused(false);

            Time.timeScale = 1f;
            Time.fixedDeltaTime = 0.02f;
        }
    }
}
