﻿using UnityEngine;
using System.Collections;

public class StoreButton : MonoBehaviour
{
    public ButtonEvents B_event;
    public Canvas canvas;

    private void Awake()
    {
        canvas.enabled = false;
    }

    public void OnClicked()
    {       
        canvas.enabled = true;
        B_event.Pause_Game(true);        
    }
}
