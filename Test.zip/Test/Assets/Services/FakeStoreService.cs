﻿using UnityEngine;
using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;

public class FakeStoreService : MonoBehaviour 
{
    public event Action<string, bool> OnPurchaseSucceeded;
    public event Action<string> OnPurchaseFailed;

    public readonly string[] _powUps =
    {
        "FireBall",
        "HyperSpace",
        "FullVersion"
    };

    private bool[] _bought = { false, false, false };

    public bool Bought(string pUps)
    {
        return _bought[Array.IndexOf(VALID_ITEMS,pUps)];
    }

    public string Pow_Up(string pUps)
    {
        return _powUps[Array.IndexOf(VALID_ITEMS, pUps)];
    }

    private bool Update_bought(string pow_up)
    {
        _bought[Array.IndexOf(VALID_ITEMS, pow_up)] = true;

        if (_bought[_bought.Length - 1])
        {
            for (int i = 0; i < _bought.Length - 1; i++)
                _bought[i] = true;

            return true;
        }

        for (int i = 0; i < _bought.Length - 1; i++)
            if (_bought[i] == false)
                return false;

        _bought[_bought.Length - 1] = true;

        return true;
    }

    public static FakeStoreService Instance()
    {
        return smInstance;
    }

    public bool Purchase(string item)
    {
        if (Bought(item))
        {
            Debug.Log("Already bought: " + item);
            return false;
        }

        if (!Array.Exists(VALID_ITEMS, validItem => validItem == item))
        {
            Debug.Log("Invalid item: " + item);
            return false;
        }
            
        if (mPendingItems.Exists(itemInfo => itemInfo.item == item))
        {
            Debug.Log("Purchase pending for item: " + item);
            return false;
        }

        float dispatchDelay = UnityEngine.Random.Range(1.0f, 3.0f);
        float dispatchTime = Time.realtimeSinceStartup + dispatchDelay;
        mPendingItems.Add(new ItemInfo(item, dispatchTime));
        return true;
    }

    private void Awake()
    {
        if (smInstance != null)
        {
            Destroy(gameObject);
            return;
        }

        if(File.Exists("dat.txt"))
            _bought = LoadData("dat.txt");

        smInstance = this;
    }

    void SaveData(bool[] data, string path)
    {
        BinaryWriter writer =
        new BinaryWriter(File.Open(path, FileMode.Create));

        for (int i = 0; i < data.Length; i++)
        {
            writer.Write(data[i]);
        }

        writer.Close();
    }

    bool[] LoadData(string path)
    {
        var value = new List<bool>();

        BinaryReader reader = new BinaryReader(File.Open(path,FileMode.Open));

        for (int i = 0; i < _bought.Length; i++)
            value.Add(reader.ReadBoolean());

        reader.Close();
        return value.ToArray();
    }

    private void Update()
    {
        mPendingItems.Sort((lhs, rhs) => { return Math.Sign(lhs.dispatchTime - rhs.dispatchTime); });

        float currentTime = Time.realtimeSinceStartup;

        int itemIndex;
        for (itemIndex = 0; itemIndex < mPendingItems.Count; ++itemIndex)
        {
            ItemInfo itemInfo = mPendingItems[itemIndex];
            if ((currentTime - itemInfo.dispatchTime) <= 0.0f)
                break;

            if (Bought(itemInfo.item)) continue;

            if (UnityEngine.Random.Range(0.0f, 1.0f) < 0.5f)
            {
                DispatchSuccess(itemInfo.item, Update_bought(itemInfo.item));
                SaveData(_bought, "dat.txt");
            }
            else
            {
                DispatchFailure(itemInfo.item);
            }
        }

        mPendingItems.RemoveRange(0, itemIndex);
    }

    private void DispatchSuccess(string item, bool upd_other)
    {
        if (OnPurchaseSucceeded != null)
            OnPurchaseSucceeded(item, upd_other);
    }

    private void DispatchFailure(string item)
    {
        if (OnPurchaseFailed != null)
            OnPurchaseFailed(item);
    }
    
    private struct ItemInfo
    {
        public ItemInfo(string item, float dispatchTime)
        {
            this.item = item;
            this.dispatchTime = dispatchTime;
        }

        public string item;
        public float dispatchTime;
    }
        
    private List<ItemInfo> mPendingItems = new List<ItemInfo>();

    private static FakeStoreService smInstance;

    private readonly string[] VALID_ITEMS =
    {
        "com.powerups.fireball",
        "com.powerups.hyperspace",
        "com.powerups.fullversion"
    };
}
